import pygame
import os
import asyncio


pygame.font.init()

#build a new window
WIDTH, HEIGHT = 900, 500
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Space Shooter")


WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)

BORDER = pygame.Rect(WIDTH//2 - 5, 0, 10, HEIGHT) #draws 0,0 point 5 points from  the centre line

FPS = 60 #update rate
VEL = 5 #velocity of ship

HEALTH_FONT = pygame.font.SysFont('comicsans', 40) #font definition
try:
    HEALTH_FONT = pygame.font.SysFont(None, 40)
    WINNER_FONT = pygame.font.SysFont(None, 100)
except Exception as e:
    print(f"Font error: {e}")

BULLET_VEL = 7 #velocity of bullets
BULLET_MAX = 5
YELLOW_HIT = pygame.USEREVENT + 1 #userevent is an unknown numer, add one to give it a unique id
RED_HIT = pygame.USEREVENT + 2

SPACESHIP_WIDTH, SPACESHIP_HEIGHT = 55, 40

def load_image(path, fallback_color):
    try:
        img = pygame.image.load(path)
        return img
    except Exception as e:
        print(f"Error loading {path}: {e}")
        surf = pygame.Surface((SPACESHIP_WIDTH, SPACESHIP_HEIGHT))
        surf.fill(fallback_color)
        return surf

YELLOW_SPACESHIP_IMAGE = load_image(os.path.join('assets', 'spaceship_yellow.png'), YELLOW)
YELLOW_SPACESHIP = pygame.transform.rotate(pygame.transform.scale(YELLOW_SPACESHIP_IMAGE, (SPACESHIP_WIDTH,SPACESHIP_HEIGHT)), 90)

RED_SPACESHIP_IMAGE = load_image(os.path.join('assets', 'spaceship_red.png'), RED)
RED_SPACESHIP = pygame.transform.rotate(pygame.transform.scale(RED_SPACESHIP_IMAGE, (SPACESHIP_WIDTH,SPACESHIP_HEIGHT)), 270)

try:
    SPACE = pygame.transform.scale(pygame.image.load(os.path.join('assets', 'space.png')), (WIDTH, HEIGHT))
except Exception as e:
    print(f"Error loading background: {e}")
    SPACE = pygame.Surface((WIDTH, HEIGHT))
    SPACE.fill(BLACK)


#------------------------
#------------------------


#draw onto display (order of objects matters within display)
def draw_window(red, yellow, red_bullets, yellow_bullets, red_health, yellow_health):

    #RGB (range = 0-255)
    WIN.blit(SPACE, (0,0)) #pygame does not remove any previously drawn objects, remove white fill
    pygame.draw.rect(WIN, BLACK, BORDER)

    red_health_text = HEALTH_FONT.render("Health: " + str(red_health), 1, WHITE)
    yellow_health_text = HEALTH_FONT.render("Health: " + str(yellow_health), 1, WHITE)
    WIN.blit(red_health_text, (WIDTH - red_health_text.get_width()- 10, 10)) #dynamic, add 10 pixel pad
    WIN.blit(yellow_health_text, (10, 10))

    #draw surface/text/image onto screen: define position (draws from top-left corner, 0,0 coordinates)
    #draws from top-left of image/object
    WIN.blit(YELLOW_SPACESHIP, (yellow.x, yellow.y))
    WIN.blit(RED_SPACESHIP, (red.x, red.y))

    for bullet in red_bullets:
        pygame.draw.rect(WIN, RED, bullet)

    for bullet in yellow_bullets:
        pygame.draw.rect(WIN, YELLOW, bullet) #update draw window() by passing arguments

    pygame.display.update() 

#----
# if you want the front of the spaceship to really stick to the boundary, 
# you can use this logic (yellow.x + yellow.width - 15)  < BORDER.x. 
# if the spaceship is red (red.x + red.width - 65) >  BORDER.x.


def yellow_handle_movement(keys_pressed, yellow):
    #checks for keys currently pressed down
    if keys_pressed[pygame.K_a] and yellow.x - VEL > 0: # LEFT
        yellow.x -= VEL
    if keys_pressed[pygame.K_d] and yellow.x + VEL + yellow.width < BORDER.x: # RIGHT
        yellow.x += VEL
    if keys_pressed[pygame.K_w] and yellow.y - VEL > 0: # UP
        yellow.y -= VEL
    if keys_pressed[pygame.K_s] and yellow.y + VEL + yellow.height < HEIGHT - 15: # DOWN   # HEIGHT - 15 fixes ship moving off bottom border
        yellow.y += VEL

def red_handle_movement(keys_pressed, red):
    #checks for keys currently pressed down
    if keys_pressed[pygame.K_LEFT] and red.x - VEL > BORDER.x + BORDER.width: # LEFT
        red.x -= VEL
    if keys_pressed[pygame.K_RIGHT] and red.x + VEL + red.width < WIDTH: # RIGHT
        red.x += VEL
    if keys_pressed[pygame.K_UP] and red.y - VEL > 0: # UP
        red.y -= VEL
    if keys_pressed[pygame.K_DOWN] and red.y + VEL + red.height < HEIGHT - 15: # DOWN
        red.y += VEL

def handle_bullets(yellow_bullets, red_bullets, yellow, red):
    for bullet in yellow_bullets:
        bullet.x += BULLET_VEL
        
        #checks for collision of rectangles
        if red.colliderect(bullet):
            pygame.event.post(pygame.event.Event(RED_HIT))
            yellow_bullets.remove(bullet)
        elif bullet.x > WIDTH:
            yellow_bullets.remove(bullet)

    for bullet in red_bullets:
        bullet.x -= BULLET_VEL
        
        #checks for collision of rectangles
        if yellow.colliderect(bullet):
            pygame.event.post(pygame.event.Event(YELLOW_HIT))
            red_bullets.remove(bullet)
        elif bullet.x < 0:
            red_bullets.remove(bullet)


def draw_winner(text):
    draw_text = WINNER_FONT.render(text, 1, WHITE)
    WIN.blit(draw_text, (WIDTH/2 - draw_text.get_width()/2, HEIGHT/2 - draw_text.get_height()/2))
    
def draw_reset():
    draw_reset = WINNER_FONT.render("Reset?", 1, WHITE)
    WIN.blit(draw_reset, (WIDTH/3 - draw_reset.get_width()/2, HEIGHT/2 - draw_reset.get_height()/2))
    
    pygame.display.update()
    pygame.time.delay(5000)


#------------------------
#------------------------
# start 
def show_start_screen(screen):
    font = pygame.font.SysFont(None, 64)
    text = font.render("Press Enter to Start", True, (255, 255, 255))
    text_rect = text.get_rect(center=(screen.get_width() // 2, screen.get_height() // 2))
    waiting = True
    while waiting:
        screen.fill((0, 0, 0))
        screen.blit(text, text_rect)
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                waiting = False
                
                # start 
def show_reset_screen(screen, winner):
    font = pygame.font.SysFont(None, 64)
    winner_text = font.render(f"Winner is {winner}!", True, (255, 255, 255))
    text = font.render("Press Enter to Reset", True, (255, 255, 255))
    text_rect = text.get_rect(center=(screen.get_width() // 2, screen.get_height() // 2))
    waiting = True
    while waiting:
        screen.fill((0, 0, 0))
        screen.blit(winner_text, (WIDTH/2 - winner_text.get_width()/2, HEIGHT/2 - winner_text.get_height()/2 - 30))
        screen.blit(text, text_rect)
        screen.blit(text, text_rect)
        
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                waiting = False


#game loop (handles game logic)
async def main():
    #define rectangle for spaceship (x,y,width,height)
    red = pygame.Rect(700, 300, SPACESHIP_WIDTH, SPACESHIP_HEIGHT)
    yellow = pygame.Rect(100, 300, SPACESHIP_WIDTH, SPACESHIP_HEIGHT)

    red_bullets = []
    yellow_bullets = []

    red_health = 10
    yellow_health = 10

    clock = pygame.time.Clock()
    run = True
    while run:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            if event.type == pygame.KEYDOWN and len(yellow_bullets) < BULLET_MAX:
                if event.key == pygame.K_LCTRL:
                    bullet = pygame.Rect(yellow.x + yellow.width, yellow.y + yellow.height//2 - 2, 10, 5)
                    yellow_bullets.append(bullet)
                if event.key == pygame.K_RCTRL and len(red_bullets) < BULLET_MAX:
                    bullet = pygame.Rect(red.x, red.y + red.height//2 - 2, 10, 5)
                    red_bullets.append(bullet)
            if event.type == RED_HIT:
                red_health -= 1
            if event.type == YELLOW_HIT:
                yellow_health -= 1
        winner = ""
        if red_health <= 0:
            winner = "Yellow"
        if yellow_health <= 0:
            winner = "Red"
        if winner != "":
            show_reset_screen(WIN, winner)
            run = False
        keys_pressed = pygame.key.get_pressed()
        yellow_handle_movement(keys_pressed, yellow)
        red_handle_movement(keys_pressed, red)
        handle_bullets(yellow_bullets, red_bullets, yellow, red)
        draw_window(red, yellow, red_bullets, yellow_bullets, red_health, yellow_health)
        await asyncio.sleep(0)  # Yield to browser

    pygame.quit()
    

#check we are running only this function 
# (so game does not run automatically)
import asyncio

if __name__ == "__main__":
    asyncio.run(main())


#------------------------
#------------------------


# additional tasks
# For anyone who followed the tutorial and want to practice more of what you learned, here's some things you could do to make the game better. 
# -Add a collision check to the bullets so if they collide, they destroy each other
# -Add poer ups that you can pick up and will increase the amount of bullets you can fire, increase bullet speed etc...
# -Add a healt system so you can get hit more times before you die
# -You could also add a healtbar if you're adding a healt system
# -You can also add different firing modes, like holding down a different key will shoot 2 bullets next to each other etc...
# -You could also add a border that slowly shrinks the space you can move around to prevent stalemates
# -You could add a score system